//
//  Event.m
//  Insurance-Needs-Calculator-PRO
//
//  Created by Daniel Adams on 24/02/12.
//  Copyright (c) 2012 A+Apps. All rights reserved.
//

#import "Event.h"


@implementation Event

@dynamic eventID;
@dynamic name;

@end
