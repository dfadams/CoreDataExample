//
//  Insurance_Needs_Calculator_PROTests.h
//  Insurance-Needs-Calculator-PROTests
//
//  Created by Daniel Adams on 22/02/12.
//  Copyright (c) 2012 A+Apps. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface Insurance_Needs_Calculator_PROTests : SenTestCase

@end
