//
//  Insurance_Needs_Calculator_PROTests.m
//  Insurance-Needs-Calculator-PROTests
//
//  Created by Daniel Adams on 22/02/12.
//  Copyright (c) 2012 A+Apps. All rights reserved.
//

#import "Insurance_Needs_Calculator_PROTests.h"

@implementation Insurance_Needs_Calculator_PROTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Insurance-Needs-Calculator-PROTests");
}

@end
